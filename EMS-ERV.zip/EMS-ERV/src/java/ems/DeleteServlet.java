/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ems;

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;

/**
 *
 * @author lenovo
 */
@WebServlet(name = "DeleteServlet", urlPatterns = {"/DeleteServlet"})
public class DeleteServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet DeleteServlet</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet DeleteServlet at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        // Retrieve service number from request parameter
        String serviceNumber = request.getParameter("serviceNumber");

        // JDBC variables
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // Establish database connection
            conn = DatabaseConnector.getConnection();

            // Prepare SQL statement to retrieve employee details
            String sql = "SELECT * FROM employee_list WHERE srno=?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, serviceNumber);
            rs = stmt.executeQuery();

            // Check if employee details exist
            if (rs.next()) {
                // Retrieve employee details from the result set
                String firstName = rs.getString("fname");
                String lastName = rs.getString("lname");
                String department = rs.getString("departement");
                String designation = rs.getString("designation");
                String contact = rs.getString("number");
                String status = rs.getString("status");
                String address = rs.getString("address");
                String salary = rs.getString("salary");

                // Create JSON object to hold employee data
                JSONObject employeeData = new JSONObject();
                employeeData.put("firstName", firstName);
                employeeData.put("lastName", lastName);
                employeeData.put("department", department);
                employeeData.put("designation", designation);
                employeeData.put("contact", contact);
                employeeData.put("status", status);
                employeeData.put("address", address);
                employeeData.put("salary", salary);

                // Write JSON response
                out.print(employeeData);
            } else {
                // Employee not found
                out.print("{}"); // Empty JSON object
            }
        } catch (SQLException | ClassNotFoundException e) {
            // Handle database error
            out.print("{}"); // Empty JSON object
        }
        // Handle class not found error
        // Empty JSON object
         finally {
            // Close resources
            // Handle exceptions
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // Retrieve service number from request parameter
    String serviceNumber = request.getParameter("serviceNumber");

    // JDBC variables
    Connection conn = null;
    PreparedStatement stmt = null;

    try {
        // Establish database connection
        conn = DatabaseConnector.getConnection();

        // Prepare SQL statement to delete employee record
        String sql = "DELETE FROM employee_list WHERE srno=?";
        stmt = conn.prepareStatement(sql);
        stmt.setString(1, serviceNumber);

        // Execute delete operation
        int rowsDeleted = stmt.executeUpdate();
        if (rowsDeleted > 0) {
            // Redirect to success page after deletion 
                out.println("Data deleted successfylly");
        } else {
            // Redirect to error page if no rows were deleted
            response.sendRedirect("error.jsp");
        }
    } catch (SQLException | ClassNotFoundException e) {
        // Redirect to error page on database error
        response.sendRedirect("error.jsp");
    } finally {
        // Close resources
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                // Ignore
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                // Ignore
            }
        }
    }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
