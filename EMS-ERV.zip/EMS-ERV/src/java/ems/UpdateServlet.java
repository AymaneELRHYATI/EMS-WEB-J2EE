package ems;

import java.io.IOException;
import org.json.JSONObject;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "UpdateServlet", urlPatterns = {"/UpdateServlet"})
public class UpdateServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        // Retrieve service number from request parameter
        String serviceNumber = request.getParameter("serviceNumber");

        // JDBC variables
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // Establish database connection
            conn = DatabaseConnector.getConnection();

            // Prepare SQL statement to retrieve employee details
            String sql = "SELECT * FROM employee_list WHERE srno=?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, serviceNumber);
            rs = stmt.executeQuery();

            // Check if employee details exist
            if (rs.next()) {
                // Retrieve employee details from the result set
                String firstName = rs.getString("fname");
                String lastName = rs.getString("lname");
                String department = rs.getString("departement");
                String designation = rs.getString("designation");
                String contact = rs.getString("number");
                String status = rs.getString("status");
                String address = rs.getString("address");
                String salary = rs.getString("salary");

                // Create JSON object to hold employee data
                JSONObject employeeData = new JSONObject();
                employeeData.put("firstName", firstName);
                employeeData.put("lastName", lastName);
                employeeData.put("department", department);
                employeeData.put("designation", designation);
                employeeData.put("contact", contact);
                employeeData.put("status", status);
                employeeData.put("address", address);
                employeeData.put("salary", salary);

                // Write JSON response
                out.print(employeeData);
            } else {
                // Employee not found
                out.print("{}"); // Empty JSON object
            }
        } catch (SQLException | ClassNotFoundException e) {
            // Handle database error
            out.print("{}"); // Empty JSON object
        }
        // Handle class not found error
        // Empty JSON object
         finally {
            // Close resources
            // Handle exceptions
        }
        
        
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         // Retrieve form data
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String department = request.getParameter("department");
        String designation = request.getParameter("designation");
        String contact = request.getParameter("contact");
        String status = request.getParameter("status");
        String address = request.getParameter("address");
        String salary = request.getParameter("salary");

        // JDBC variables
        Connection conn = null;
        PreparedStatement stmt = null;

        // Database update query
        String updateQuery = "UPDATE `employee_list` SET `fname`=?, `lname`=?, `departement`=?, `designation`=?, `number`=?, `status`=?, `address`=?, `salary`=? WHERE `srno`=?";

        try {
            // Establish database connection
            conn = DatabaseConnector.getConnection();

            // Prepare statement
            stmt = conn.prepareStatement(updateQuery);
            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setString(3, department);
            stmt.setString(4, designation);
            stmt.setString(5, contact);
            stmt.setString(6, status);
            stmt.setString(7, address);
            stmt.setString(8, salary);
            // Assuming there's an ID to identify the employee record, replace 'id' with your actual column name
            stmt.setString(9, request.getParameter("serviceNumber")); // Assuming you have an 'id' parameter in your form

            // Execute update
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) { 
                out.println("Data updated successfylly");
            } else {
                response.sendRedirect("error.jsp"); // Redirect to error page if no rows were updated
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp"); // Redirect to error page on database error
        
        }
    }

    @Override
    public String getServletInfo() {
        return "Servlet for updating employee information";
    }
}
