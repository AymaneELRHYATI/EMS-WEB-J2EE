/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ems;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/login")
public class Login extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            String uemail = request.getParameter("username");
            String upwd = request.getParameter("password");
            Connection con = null;
            HttpSession session = request.getSession();
            RequestDispatcher dispatcher = null;
            
            if(uemail == null || uemail.equals("")){
                session.setAttribute("status","invalid" );
                dispatcher = request.getRequestDispatcher("login.jsp");
            }
            
            if(upwd == null || upwd.equals("")){
                session.setAttribute("status","invalid" );
                dispatcher = request.getRequestDispatcher("login.jsp");
            }
            
            try{
                con = DatabaseConnector.getConnection();
                PreparedStatement pst = con.prepareStatement("SELECT * FROM `users` where email = ? and password = ?");
                
                pst.setString(1, uemail);
                pst.setString(2, upwd);
                
                ResultSet rs = pst.executeQuery();
                if(rs.next()){
                    session.setAttribute("name",rs.getString("uname"));
                    dispatcher = request.getRequestDispatcher("index.jsp");
                }else{
                    request.setAttribute("status", "failed");
                    dispatcher = request.getRequestDispatcher("login.jsp");
                }
                dispatcher.forward(request, response);
            }catch(Exception e){
                e.printStackTrace();
            }
    }


    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
