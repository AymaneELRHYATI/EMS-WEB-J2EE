/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ems;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author lenovo
 */
@WebServlet(name = "add", urlPatterns = {"/add"})
public class add extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet add</title>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Servlet add at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
            
            
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Connection connection = null;
        try {
            connection = DatabaseConnector.getConnection();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(add.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (connection != null) {
            try {
                // Perform database operations here
                PreparedStatement statement = connection.prepareStatement("SELECT * FROM `employee_list`");
                ResultSet resultSet = statement.executeQuery();
                while (resultSet.next()) {
                    // Process each row
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    connection.close(); // Close the connection when done
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        } else {
            // Handle connection failure
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
         response.setContentType("text/html;charset=UTF-8");
    PrintWriter out = response.getWriter();
    
    // Retrieve form data
    String firstName = request.getParameter("Fname");
    String lastName = request.getParameter("Lname");
    String[] departments = request.getParameterValues("Department");
    String[] designations = request.getParameterValues("Designation");
    String contact = request.getParameter("Number");
    String address = request.getParameter("Address");
    String salary = request.getParameter("Salary");

    // Initialize department and designation variables
    String department = null;
    String designation = null;

    // Check if both department and designation arrays are not null and have at least one value
    if (departments != null && departments.length > 0 && designations != null && designations.length > 0) {
        // Assuming only one value is selected, so getting the first value
        department = departments[0];
        designation = designations[0];
    }

    // Determine the status based on the checkboxes
    String status = "In-Active"; // Default status
    if (request.getParameter("activeCheckbox") != null) {
        status = "Active";
    }

    // JDBC variables
    Connection conn = null;
    PreparedStatement stmt = null;
    
    try {
        // Establish database connection
        conn = DatabaseConnector.getConnection();
        
        // Prepare SQL statement
        String sql = "INSERT INTO `employee_list`(`fname`, `lname`, `departement`, `designation`, `number`, `status`, `address`, `salary`) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        stmt = conn.prepareStatement(sql);
        stmt.setString(1, firstName);
        stmt.setString(2, lastName);
        stmt.setString(3, department);
        stmt.setString(4, designation);
        stmt.setString(5, contact);
        stmt.setString(6, status);
        stmt.setString(7, address);
        stmt.setString(8, salary);
        
        // Execute the statement
        int rowsAffected = stmt.executeUpdate();
        
        // Inform the user about the operation result
        if (rowsAffected > 0) {
            out.println("<h2>Data inserted successfully!</h2>");
            out.println("<button type=\"button\" class=\"btn btn-primary\">Add</button>");
        } else {
            out.println("<h2>Failed to insert data. Please try again.</h2>");
        }
    } catch (SQLException e) {
        out.println("<h2>Error: " + e.getMessage() + "</h2>");
    } catch (ClassNotFoundException ex) {
        out.println("<h2>Error: " + ex.getMessage() + "</h2>");
    } finally {
        // Close resources
        if (stmt != null) {
            try {
                stmt.close();
            } catch (SQLException e) {
                // Ignore
            }
        }
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                // Ignore
            }
        }
        out.close();
    }
   }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
